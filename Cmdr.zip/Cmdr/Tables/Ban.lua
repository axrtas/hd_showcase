local BannedPlayersModule = {}

BannedPlayersModule.bannedPlayers = {}

return BannedPlayersModule
