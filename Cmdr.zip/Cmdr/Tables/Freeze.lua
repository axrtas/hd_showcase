local FrozenPlayersModule = {}

FrozenPlayersModule.frozenPlayers = {}

return FrozenPlayersModule